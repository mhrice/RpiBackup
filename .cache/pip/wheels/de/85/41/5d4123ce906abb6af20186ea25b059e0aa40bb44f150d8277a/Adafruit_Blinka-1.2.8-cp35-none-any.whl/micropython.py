def const(x):
    return x
